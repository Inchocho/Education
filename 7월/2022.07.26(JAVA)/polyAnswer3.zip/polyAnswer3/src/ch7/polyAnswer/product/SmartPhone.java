package ch7.polyAnswer.product;

public class SmartPhone extends Product {

	public SmartPhone() {
		super(70);
		name = "폰 사용 중";
		// TODO Auto-generated constructor stub
	}

	public String toString() {
		return "SmartPhone";
	}

}
