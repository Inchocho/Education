package ch7.polyAnswer.product;

public class Book extends Product {
	
	public Book() {
		super(1);
		name = "책 읽는 중";
		// TODO Auto-generated constructor stub
	}

	public String toString() {
		return "Book";
	}
}
