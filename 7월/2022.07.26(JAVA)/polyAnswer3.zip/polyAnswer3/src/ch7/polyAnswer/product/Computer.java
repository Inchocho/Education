package ch7.polyAnswer.product;

public class Computer extends Product {
	public Computer() {
		super(200);
		name = "컴퓨터 사용 중";
	}

	public String toString() {
		return "Computer";
	}
}
