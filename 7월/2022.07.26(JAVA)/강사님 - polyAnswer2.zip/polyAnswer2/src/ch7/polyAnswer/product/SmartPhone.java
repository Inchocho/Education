package ch7.polyAnswer.product;

public class SmartPhone extends Product {

	public SmartPhone() {
		super(70);
		// TODO Auto-generated constructor stub
	}

	public void use() {
		System.out.println("폰 사용 중");
	}
	
	public String toString() {
		return "SmartPhone";
	}

}
