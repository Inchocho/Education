package ch7.polyAnswer.product;

public class Computer extends Product {
	public Computer() {
		super(200);
	}

	public String toString() {
		return "Computer";
	}

}
