package oop_animal;

public class Animal {
	
	String name = "";
	String nick = "";
	int price = 0;
	

	void setName() {
		System.out.println("이름");
	}
	
	void setName(String name) {
		System.out.println(name);
	}
	
	
}
