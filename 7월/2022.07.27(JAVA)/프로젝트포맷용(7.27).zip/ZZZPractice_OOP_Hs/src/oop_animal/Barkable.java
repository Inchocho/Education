package oop_animal;

public interface Barkable {

	void bark();
}
