package oop_animal;

public interface Predator {
	void getFood();
}
