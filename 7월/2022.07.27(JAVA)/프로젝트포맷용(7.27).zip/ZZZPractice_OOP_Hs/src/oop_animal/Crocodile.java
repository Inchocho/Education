package oop_animal;

public class Crocodile extends Animal implements BarkablePredator {

	@Override
	public void getFood() {
		// TODO Auto-generated method stub

	}
	
	@Override
	public void bark() {
		System.out.println("악어는 어케우냐고 왕왕");
	}

}
