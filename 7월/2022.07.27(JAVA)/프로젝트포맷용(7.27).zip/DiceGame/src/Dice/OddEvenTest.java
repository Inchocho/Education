package Dice;

import java.util.Scanner;

public class OddEvenTest {

	public static void main(String[] args) {
		
		int num = 0;
		
		OddEven ode = new OddEven();
		System.out.println("판별하실 값을 입력해주세요.");
		Scanner scan = new Scanner(System.in);
		num = scan.nextInt();
		ode.chkOdd(num);
	}
}
