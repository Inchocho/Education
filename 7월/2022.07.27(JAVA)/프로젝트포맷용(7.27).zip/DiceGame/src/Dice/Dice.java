package Dice;

public class Dice {

	int num = 0;	

	void diceRoll() {
		System.out.println("주사위를 굴렸습니다.");
		this.num = (int) ((Math.random() * 6) + 1);
	}

	void viewDiceNum() {
		System.out.println("나온 숫자는 " + this.num + " 입니다.");
	}
}
