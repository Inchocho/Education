package Dice;

public class OddEven {

	void chkOdd(int n) {
		if (n % 2 == 0) {
			System.out.println("짝");
		} else {
			System.out.println("홀");
		}
	}
}
