/*
 * 이 클래스에 자신의 이름과 대학교명을 출력하시오
 */
public class SampleProject {
	
	public static void main(String[] args) {
		
		String uni = "강릉원주대";
		String name = "조현석";
		
		System.out.println(uni+"를 졸업한 "+name+" 입니다.");
	}
}