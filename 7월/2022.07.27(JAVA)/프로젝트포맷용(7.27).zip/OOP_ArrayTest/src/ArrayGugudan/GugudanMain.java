package ArrayGugudan;

public class GugudanMain {

	public static void main(String[] args) {
		
		Gugudan gu = new Gugudan();
		gu.setGugudan(5);
		System.out.println(gu.getGugudan2(5));
		System.out.println("깃허브");
	}
}
