import java.util.*;

public class OddEvenThreeCondition {

	public static void main(String[] args) {		

//		홀짝 판별프로그램 삼항식		
		int userInputNum = 0;
		String resultStr = "";
		
		Scanner scan = new Scanner(System.in);
		
//		int inputNum = 100;
//		resultStr = (inputNum%2 == 0) ? inputNum + "= 짝수" : inputNum + "= 홀수";
//		
//		System.out.println(resultStr);
//		inputNum = 99;
//		
//		resultStr = (inputNum%2 == 0) ? inputNum + "= 짝수" : inputNum + "= 홀수";
//		System.out.println(resultStr);
		
		System.out.println("숫자를 입력하세요.");
		userInputNum = scan.nextInt();
		
//		boolean zeroNum = false; 
//		zeroNum = userInputNum == 0;		
		
		resultStr = (userInputNum % 2 == 0) ? userInputNum + "=짝수" : userInputNum + "=홀수";
		resultStr = (userInputNum == 0) ? userInputNum + "=-" : resultStr;
		
		System.out.println(resultStr);
		
//		resultStr = (zeroNum ? "입력값 =" + userInputNum : (userInputNum % 2 == 0) 
//		? userInputNum + "= 짝수" : userInputNum + "= 홀수");
//
//		System.out.println(resultStr);
//		
		scan.close();
		
	}

}
