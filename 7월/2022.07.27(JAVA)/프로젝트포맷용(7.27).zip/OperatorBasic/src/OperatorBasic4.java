
public class OperatorBasic4 {
	
	public static void main(String[] args) {
		
//		단항 연산자
//		증감 연산자
//		
//		++연산자: 피연산자의 값을 1증가시킨다
//		--연산자: 피연산자의 값을 1감소시킨다
//		
//		전위형: 값이 참조되기 전에 증가시킨다
//		ex: ++i;x
//		후위형: 값이 참조된 후에 증가시킨다
//		ex: i++;
		
		int n = 5;
		n++; // n+1
				
		System.out.println(n);
		
		int ab23 = 5;
		System.out.println("========================");
		System.out.println(ab23++); // 5 (+1) ab = 6
		System.out.println(ab23);
		System.out.println("========================");
		
		n=5;
		++n; // 1+n
		
		System.out.println(n);
		
		int i = 5;
		int ii = 5;
		System.out.println("i는 " + i--);
		System.out.println(i);
		System.out.println("ii는 " + --ii);
		System.out.println(ii);
		System.out.println("i=" + i + " ii=" + ii);
		
		int ab = 5;
		System.out.println("ab는 " + ab--);
		System.out.println(ab);
		
		int j = 10;
		System.out.println("j는 " + j--);
		System.out.println(j);
				
	}
}
