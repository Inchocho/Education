
public class OperatorBasic1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		연산자
//		
//		연산자: 연산을 수행하는 기호(+,- 등) 
//		피연산자: 연산자의 작업 대상(변수, 상수, 리터럴등)
		
		int firstNum = 0;
		double secondNum = 0;
		
		firstNum = 10;
		secondNum = 4;
		
		System.out.println(firstNum + secondNum);		
		System.out.println(firstNum * secondNum);
		
//		10 / 4 (정수(int)와 정수(int)) int타입으로 결과에 대해 계산됨 -> 즉 결과도 정수로 나옴 (정수/정수)=(정수)		
		System.out.println(firstNum / secondNum);		
//		10(정수 int타입) / 4.0(실수(double타입)) -> 자동형변환 (int -> double) -> 결과 실수로 나옴 즉 firstNum이 10.0  
		System.out.println(firstNum / 4.0);		
		
	}

}
