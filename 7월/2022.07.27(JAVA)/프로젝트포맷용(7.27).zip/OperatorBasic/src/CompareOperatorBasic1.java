
public class CompareOperatorBasic1 {
	
	public static void main(String[] args) {

//		비교연산자(결과 true/false)
		
//		등가비교연산자의 종류와 연산결과
//		== 두 값이 같다 -> 두 값이 같으면, true 아니면 false
//		!= 두 값이 다르다 -> 두 값이 다르면, true 아니면 false
		
		int num = 10;
		int num2 = 20;
		
		System.out.println(1 == 2);		 //false		
		System.out.println(num != num2); //true
		System.out.println(num > 2);	 //true
		
	}
}
