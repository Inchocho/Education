
public class AssignOperBasic1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		대입연산자

		int num = 0;

		num += 3;	// num = num + 3 = 6

		System.out.println(num);

		num *= 2;	// num = num * 2 = 12

		System.out.println(num);
	}

}
