
public class LogicalOperatorBasic1 {
	
	public static void main(String[] args) {

//		논리연산자
//		|| (or연산자)
//		피연산자 중 어느 한 쪽만 true이면 true를 결과로 얻는다
//		&& (and연산자)
//		피연산자 중 양쪽 모두 true이어야 true를 결과로 얻는다
//		! (부정연산자)
//		true는 false로, false는 true로 변환한다.
		
		int num = 10;
		int num2 = 20;
		
		System.out.println(num >=1 && num2 <= 30); // 변수 num이 1이상 AND num2가 30이하
		System.out.println(num >=1 || num2 <= 30); // 변수 num이 1이상  OR num2가 30이하
		System.out.println(!(num >=1 || num2 <= 30)); //true 이므로 false 반환
		
	}
	
}
