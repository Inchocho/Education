
public class TernaryOperatorBasic1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		삼항연산자 Ternary Operator
		
//		표현식
//		조건 연산자 ? :
//		조건식(x > y)이 참이면 식1(x : y) 에서 (x)을 반환한다.
//		조건식(x < y)이 거짓이면 식2(x : y) 에서 (y)를 반환한다.
		
		int x = 4;
		int y = 2;
		int resultNum = 0;
		String resultString = "";
		
		resultNum = (x < y) ? x : y ;		
		System.out.println(resultNum); // 조건식이 거짓이므로 (x < y) x:y , y(2)가 출력됨
		resultNum = (x < y) ? x : 50000 ;		
		System.out.println(resultNum); // 조건식이 거짓이므로 (x < y) x:50000, 50000이 출력
		
		resultNum = (x > y) ? x : y ;	// 조건식이 참이므로 x(4)가 출력됨
		
		System.out.print("두 숫자 중 큰 값은? ");
		System.out.println(resultNum);
		
		resultNum = (x > y) ? ++x : --x;	 
		System.out.println(resultNum);
		
		resultString = (x < y) ? "문자열 1번식(조건참)" : "문자열 2번식(조건거짓)" ;
		System.out.println(resultString);
		
	}

}
