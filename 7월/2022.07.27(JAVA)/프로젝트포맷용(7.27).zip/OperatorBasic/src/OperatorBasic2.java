
public class OperatorBasic2 {
	
	public static void main(String[] args) {
		
//		소수점 3번째 자리까지 구하는 내림처리
		double pi = 3.141592D;
//		3141.592		
		double shortPi = 0.0;
//		(1)pi*1000(3141.592) -> (2)int형변환(3141) -> (3)/1000.0 (3141/1000.0) = 3.141
		shortPi = (int)(pi*1000)/1000.0;
		
		
		System.out.println((int)3141.592);		
		System.out.println(pi);
		System.out.println(shortPi);		
		
	}
}
