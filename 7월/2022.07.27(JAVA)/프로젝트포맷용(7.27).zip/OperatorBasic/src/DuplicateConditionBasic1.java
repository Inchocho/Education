import java.util.Scanner;

public class DuplicateConditionBasic1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		ctrl + shift + f = 들여쓰기 정렬
		
//		삼항연산자
//		조건식 ? 식1 : 식2
		
//		중첩삼항연산자
//		조건식 ? 식1 : 조건식(2) ? 식(2-1) : 식 (2-2)
		
		int aceNum = 1;
		String chkStr2 = (aceNum != 1) ? aceNum+"= 1" : (aceNum == 1) ? "입력값= 1" : "Not 1";
		
		
		int fNum = 1;
		String chkStr = (fNum != 1) ? fNum+"= 1" : (fNum == 1) ? "입력값= 1" : "Not 1";
		System.out.println(chkStr);
		
		Scanner scan = new Scanner(System.in);
		int num = 0;
		String numText = "";

		System.out.println("숫자를 입력하세요");
		num = scan.nextInt();

//      중첩 삼항연산자
		numText = (num > 0) ? "양수" : (num < 0) ? "음수" : "0";

		System.out.print("입력한 숫자는" + num + "\n");
		System.out.println(num + "는 " + numText + "입니다");

	}
}
