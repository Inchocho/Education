
public class OperatorBasic3 {
	
	public static void main(String[] args) {
		
//		나머지 연산자 %
		
		int x = 10;
		int y = 3;
		
//		10 / 3 ... 1 <- 나머지값		
		System.out.println(x % y);		
				
		
	}
}
