
public class CastingTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//long , int long의 값을 int에다가 저장하고 출력 (형변환) 
		
//		long num = 0;
//		num = 14921422515913133L; //숫자 기본형은 int이므로 long타입 사용시 끝에 l(L)표기
//		int a = 0;
//		a = (int)num;		
//		System.out.println(num);		
//		System.out.println(a);
		
		long longNumber = 1000;
		int intNumber = 10;
		
		intNumber = (int)longNumber;
		
		System.out.println(longNumber);
		System.out.println(intNumber);
		
		longNumber = intNumber;

	}

}
