
public class CastingTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		byte bNum = 1;
		byte otherBNum = 10;
		int iNum = 1;
		int otherINum = 10;
		long lNum = 1;
		long otherLNum = 10;
		
		bNum = (byte)iNum;
		System.out.println(bNum+" int형 iNum을 byte형으로 형변환");
		bNum = (byte)lNum;
		System.out.println(bNum+" long형 lNum을 byte형으로 형변환");
		iNum = bNum;
		System.out.println(iNum+" byte형인 bNum은 묵시적으로 int형으로 형변환됨(따로 표기안해도 묵시적 형변환)");
		iNum = (int)lNum;
		System.out.println(iNum+" long형인 lNum은 int형으로 형변환");
		lNum = bNum;
		System.out.println(lNum+" byte형인 bNum은 묵시적으로 long형으로 형변환됨(따로 표기안해도 묵시적 형변환)");
		lNum = iNum;
		System.out.println(lNum+" int형인 iNum은 묵시적으로 long형으로 형변환됨(따로 표기안해도 묵시적 형변환)");
		bNum = otherBNum;
		System.out.println(bNum+" otherBNum은 같은 byte형이므로 형변환 없음");
		iNum = otherINum;
		System.out.println(iNum+" otheriNum은 같은 int형이므로 형변환 없음");
		lNum = otherLNum;
		System.out.println(lNum+" otherLNum은 같은 long형이므로 형변환 없음");
		
		
		
				
		
		
		
		
		
		
		
	}

}
