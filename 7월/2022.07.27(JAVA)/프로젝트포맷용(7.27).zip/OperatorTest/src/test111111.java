
public class test111111 {
	public static void main(String[] args) {
		
		int a = 5;
		int b = 10;
		
		System.out.println(a != 5 || b == 10 && a != 5);
	}
}
