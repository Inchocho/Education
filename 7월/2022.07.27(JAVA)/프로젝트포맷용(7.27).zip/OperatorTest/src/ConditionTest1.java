import java.util.*;

public class ConditionTest1 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
//		삼항연산자를 사용해서 
//		resultNum = (x < y) ? x : y ;
		
//		음수 양수를 판별하는 프로그램을 만드시오
//		입력한 숫자는 4
//		4는 양수입니다.
		
//		int pNum = 1;
//		int mNum = -1;
//		Boolean chkNum;
//		String resultNum2 = "";
//		
//		chkNum = (pNum > 0 ? true : false);
//		
//		System.out.println(chkNum);
//		
//		resultNum2 = chkNum ? pNum + "은 양수입니다." : pNum + "은 양수가 아닙니다.";		
//		System.out.println(resultNum2);
//		
//		pNum = -5;		
//		chkNum = (pNum > 0 ? true : false);
//		
//		resultNum2 = chkNum ? pNum + "은 양수입니다." : pNum + "은 양수가 아닙니다.";		
//		System.out.println(resultNum2);
//		
				
		
		System.out.println("숫자를 입력하세요.");
		int num = scan.nextInt();
		
		String resultNum = "";
		
		resultNum = (num*-1 < 0) ? num + "= 양수" : num + "= 음수";
		
		System.out.print("입력한 숫자는 " + num + " 입니다.\n" );
		System.out.println(resultNum);
		
		
//		System.out.println("숫자를 입력하세요.");
//		int num3 = scan.nextInt();
//		
//		String resultNum3 = "";
//		
//		resultNum3 = (num3%2 == 0) ? num3 + "는 짝수입니다" : num3 + "는 홀수입니다.";
//		
//		System.out.print("입력한 숫자는 " + num3 + " 입니다.\n" );
//		System.out.println(resultNum3);
				
		scan.close();

	}

}
