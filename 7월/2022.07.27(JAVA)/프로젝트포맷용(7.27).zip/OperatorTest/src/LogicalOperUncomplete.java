import java.util.*;

public class LogicalOperUncomplete {
	public static void main(String[] args) {
		System.out.println("조건1을 입력해주세요.");
		Scanner scan = new Scanner(System.in);
		int input = scan.nextInt();
		System.out.println("조건2를 입력해주세요.");
		int input2 = scan.nextInt();
		int num = 5;
		int n = 150;
		int input3 = 0;
		int input4 = 100;
		
//		System.out.println(5 > 0 && 5 < 9);
//		System.out.println(10 > 0 && 10 < 9);
		
		System.out.println("변수 num = " + num + "는 " + input +" 보다 크고 " + input2 + "보다는 작은가?" +" 결과:"+
		(num > input && num < input2));		
		
		num = -5;
		System.out.println(num > input && num < input2);
		
		System.out.println(n < input3 || n > input4);				
		n = 25;
		System.out.println(n < input3 || n > input4);
		scan.close();
	}
}
