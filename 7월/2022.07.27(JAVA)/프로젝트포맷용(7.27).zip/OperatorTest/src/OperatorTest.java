
public class OperatorTest {
	
	public static void main(String[] args) {
		
//		반올림하여 소수 2번째 까지 구하는 프로그램 
		double pi = 3.141592D;	
		double shortPi = 0.0;
		
		shortPi = pi + 0.005;
		shortPi = (int)(pi*100)/100.0;
		
		System.out.println(shortPi);
		  
//		반올림 -> 5이상 올림이므로 소수3번째 자리까지면 기본값에 0.0005(4번째자리에 5를더해서) 계산한다.
//		변수에 값을 더한게 아니라 수식에 바로 더한경우(위에는 변수에 더함)		
		double shortPi2 = (int)((pi+0.0005)*1000)/1000.0;
		
//		3.147 -> 3.15
		
//		지금해야되는게 3.141 까지가져와서 반올림해서 3.14를 받아야되는거니까 
		
		System.out.println(pi);		
		System.out.println(shortPi2);		
		
	}
}
