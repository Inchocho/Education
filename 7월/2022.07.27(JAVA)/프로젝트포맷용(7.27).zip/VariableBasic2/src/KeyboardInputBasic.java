import java.util.Scanner;

public class KeyboardInputBasic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//클래스 Scanner타입
		Scanner scan = new Scanner(System.in);
		int num = 0;
		String name = "";
		
		System.out.println("숫자를 하나 입력해주세요");	 //상호작용을 위한 인터페이스 문장, 없어도 작동하지만 무슨내용인지 알 수 없음
		num = scan.nextInt();					 //실제로 작동하는부분 nextInt() Int 타입으로 키보드 입력받음
		
		scan.nextLine();						 
		
		System.out.println("여기는 문장을 입력하시면 되요");
		name = scan.nextLine();					 //nextLine() String 타입으로 키보드 입력받음
		
//		System.out.println("사용자님이 입력하신 숫자는 ");
//		System.out.println(num + " 입니다");
		
		System.out.print("사용자님이 입력하신 숫자는 ");	//print() println()줄바꿈
		System.out.println(num + " 입니다");		
		
		System.out.println("사용자님이 입력하신 글자는 ");
		System.out.println(name + " 입니다");
		
		scan.close();
	}

}
