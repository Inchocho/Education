
public class CastingBasic2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		  묵시적 형변환 
//		  float to double
//		  long to float 
//		  int to long 
//		  char to int
//		  short to int
//		  byte to short
		
//		  명시적 형변환
//		  byte b = 25;
//		  int a = 200;		
//		  b = (byte)a;		
		
		byte bNum = 1;
		byte otherBNum = 1;
		int intNum = 1;
		long longNum = 1;
		
		System.out.println("본인 타입?");
		System.out.println(bNum);	 //byte타입 1
		System.out.println(intNum);	 //int타입 1
		System.out.println(longNum); //long타입 1
		
		bNum = (byte)intNum; //Type mismatch: cannot convert from int to byte 에러 bNum byte타입 intNum int타입
		bNum = otherBNum; //둘다 byte타입으로 일치함
		
		intNum = 128;
		
//		bNum = (byte)128;
//		bNum = (byte)1;
//		bNum = 1;
		
//		bNum = (byte)intNum;
		intNum = bNum;	//이경우 byte타입 bNum은 intNum int타입으로 묵시적 형변환이 된다. (int)bNum 처리가됨
		
//		무조건 왼쪽타입으로 맞춰줘야된다. (왼쪽타입 변수에 값을 넣어야 되므로)
		
		System.out.println("int의 자료형을 byte형에 대입한다.");
		System.out.println(bNum);	//-128이 나옴 (byte범위 -128~127이므로 127+1 -> -128)	 
		System.out.println(intNum);	 
		System.out.println(longNum); 				
		
//		왼쪽(변수)타입이 더 커도 작은타입을 큰타입으로 형변환해야됨 이경우 묵시적으로 명시안해도 형변환됨.		
		long aa = 1012391241024L;
		int bb = 123412125;
		
		aa = bb;	//이경우 실제로 aa = (long)bb가 되는것
		System.out.println(aa);		
		
		
	}

}
