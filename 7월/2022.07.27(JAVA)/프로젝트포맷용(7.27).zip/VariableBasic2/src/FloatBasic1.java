
public class FloatBasic1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		실수형
//		float 4byte		7자리
//		double 8byte	15자리 -> 주로사용 
		
		
//		float f = -1.12345; (이경우 error발생 default로 double로 설정되있음) float타입을 사용하려면 끝에f를 입력해줘야함		
		float f = -1.12345f;
		double d = 12.098765; // double d = 12.098765d;인데 기본형이 double이므로 생략가능 
		
		System.out.println(f);
		System.out.println(d);
	}

}
