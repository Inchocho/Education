
public class CastingBasic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		형변환(casting)이란?
//		변수 또는 상수의 타입을 다른 타입으로 변환하는 것
		
//		자동 형변환의 규칙
//		기존의 값을 최대한 보존 할 수 있는 타입으로 자동 형변환 한다.
		
//		  1		  2		  4		  8 	  4		   8byte
//		byte -> short -> int -> long -> float -> double 
//				char  -> int
//		기본형의 자동 형변환이 가능한 방향
		
//		1. boolean을 제외한 나머지 7개의 기본형은 서로 형변환이 가능하다
//		2. 기본형과 참조형은 서로 형변환 할 수 없다
//		3. 서로 다른 타입의 변수간의 연산은 형변환을 하는 것이 원칙이지만,
//		값의 범위가 작은 타입에서 큰 타입으로의 형변환은 생략 할 수 있다
		
//		명시적(explicit) vs 묵시적(implicit)
//		수동				  자동
//		자신이 직접 작성		  컴파일러가 알아서 작성
		
//		short a = 125;
//		byte ba = 'a';
//		
//		a = ba; // byte 타입은 short타입으로 자동 형변환됨 (묵시적 형변환)
//		ba = (byte)a; // byte타입으로 short타입 a를 (byte)명시하여 형변환해야됨 (명시적 형변환)
		
//		형변환 방법
//		(타입)피연산자
		
		double d = 8.13;	//실수형 타입
		int score = 0;		//정수형 타입

//		score = d; -> 에러 int score(4byte), double d(8byte) 불가능
		score = (int)d;	// score 변수에 int형(정수)으로 형변환한 d를 넣는다 강제로 int형으로 형변환
		
		System.out.println(d);
		System.out.println(score);
		

	}

}
