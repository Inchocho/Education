
public class NumberTypeEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		정수형
//		byte, short, int, long
//		1     2      4    8

//		정수형 기본은 int (즉 1221125 = 1221125i)로 보면됨
//		long의 경우 1221125112311l로 끝에 l표기해야됨(1.1123f)처럼
		
//		자료형	저장	가능한	값의	범위	크기
//		byte	-128~127			8bit	1byte	
//		int		약-20억~+20억			32bit	4byte	
//		long	엄청	큼				64bit	8byte	
//		정수형의	표현범위
				
//		가독성(Tab, Space 사용)
		
		byte b = 1;
		int num = 10;
		
		System.out.println(b);
		System.out.println(num);
		
		System.out.println("===========================");
		
		b = (byte)130;	//byte b의 범위 -128~127 범위를 벗어남 --> (byte)130; 강제로 byte형변환
		//byte는 -128~127 -> 127에서 +3이동 -> -128 -> -127 -> -126 (범위안에서 순환됨)
		num = 10000;	//int num의 범위 -21억~21억 (2^-31~2^31)
		
		System.out.println(b);
		System.out.println(num);		
		
		b = (byte)128;	// -128나옴 (127에서 +1) 127 -> -128 타입에의해 범위가 제한됨(-128~127) 
		System.out.println(b);
	}

}
