
public class BooleanEx1 {
	
	public static void main(String[] args) {
		
//		(주석처리 단축키 ctrl+shift+c , ctrl + /)		
//		논리형(true / false) 
//		true와 false 중 하나만 저장 가능
//		기본값은 false이다
		
		boolean power = true;
		
		System.out.println(power);
			
		
	}
	
}
