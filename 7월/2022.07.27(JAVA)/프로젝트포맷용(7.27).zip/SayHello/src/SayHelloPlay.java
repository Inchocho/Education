import java.util.*;

public class SayHelloPlay {

	public static void main(String[] args) {
		
		System.out.println("철수: 안녕 밥 먹었어?");
		
		System.out.println("영희: 안녕 응");
		
		System.out.println("철수: 머 먹었어?");
		
		System.out.println("영희: 끝내주는 갈비찜");		
		
	}
}
