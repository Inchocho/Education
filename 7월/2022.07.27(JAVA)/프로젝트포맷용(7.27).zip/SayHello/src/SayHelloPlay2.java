import java.util.*;

public class SayHelloPlay2 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
				
		String chulSu = "";
		String youngHi = "";
		
		chulSu = "건모";
		youngHi = "나라";
		
		System.out.println("가격을 입력해주세요.");
		int price = scan.nextInt();
		
		System.out.println(chulSu +  ": 안녕 밥 먹었어?");
		
		System.out.println(youngHi + ": 안녕 응");
		
		System.out.println(chulSu +  ": 머 먹었어?");
		
		System.out.println(youngHi + ": 끝내주는 갈비찜");
		
		System.out.println(chulSu +  ": 얼마짜리?");
		
		System.out.println(youngHi +": "+ price+"원 짜리");

	}
}
