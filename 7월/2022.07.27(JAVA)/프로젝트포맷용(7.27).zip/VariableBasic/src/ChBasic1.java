public class ChBasic1 {
	public static void main(String[] args) {
		
		// 아스키코드 '' 형태 아스키코드표
		char ch = 'a';	//10진수로 97 16진수로 0x60 문자로 a
		
		System.out.println(ch);		
		System.out.println(ch + 1);	//98 -> 인코딩이 된것이다.
		
		System.out.println((char)(ch + 1));	//b 이건 나중에  -> 디코딩이 된것(복호화) 
		
	}
}