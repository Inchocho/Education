public class VarExchangeEx2 {

	public static void main(String[] args) {	//main메소드 프로그램의 시작지점
		
		int x = 10;
		int y = 20;
		int temp = 0;
		
		System.out.println("x: " + x + " y: " + y);
		
		temp = x;	// temp에 x(10) 할당 -> temp = 10;
		x = y;		// x에 y(20) 할당	-> x = 20;
		y = temp;	// y에 temp(10) 할당 -> y = 10;
		
		System.out.println("x: " + x + " y: " + y);
					
		}
	
}