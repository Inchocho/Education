public class VarTest {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		변수란
//		단, 하나의 값을 저장할 수 있는 메모리 공간
//		
//		하나의 변수에 단 하나의 값만 저장할 수 있다.
//		
//		변수의 선언과 초기화
//		
//		int age; age라는 이름의 변수를 선언
//		
//		변수의 초기화란
//		변수를 사용하기 전에 처음으로 값을 저장하는 것 (한번만 일어남 -> 그이후로는 값을 할당만)
//		
//		int age = 25; 변수 age를 선언하고 25로 초기화 한다.
//
		
		int year = 0;	
		int age = 14;		
		
		System.out.println(year);
		System.out.println(age);

		// lvalue(left value)공간 = rvalue(right value)값
		//실행순서 -> age+2000(rvalue)가 먼저 실행됨 2014 -> year(left value)공간에 할당이됨		
		year = age + 2000; 
		age = age + 1;
		
		System.out.println(year);
		System.out.println(age);
				
		
	}
}