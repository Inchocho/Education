public class StringBasic1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		문자타입 캐릭터타입(character약자 char) 		
		char ch = 'j';	//2byte ' '에 작성 

//		문자열타입 스트링타입
		String str = "java"; //4byte " "에 작성 (lValue 저장 = rValue 연산) int a = 25+25;
		
		System.out.println("=== 처음 값 출력 ===");
//		System.out.println(ch);		
		System.out.println(str);
		
//		ch = 'a';	//문자타입 2byte 한글자만 저장가능 char 
//		str = "BACEDEFQWEWRQWAZXCZCASDAF";
		str = str + " Study" + ch;		
//		+?: concat 더하기연산자(이어붙인다)
		int a = 25+25;		
		
		System.out.println("===값 변경함===" + str);
//		System.out.println(ch);		
		System.out.println(str);		
		System.out.println(a);
		
	}

}