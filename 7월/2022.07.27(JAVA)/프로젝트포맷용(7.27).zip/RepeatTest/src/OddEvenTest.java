import java.util.Scanner;

public class OddEvenTest {
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int num = 0;
		int input = 0;
		String answer = "";
//		String exit = "";
//		
//		System.out.println("게임을 종료하시겠습니까?");
//		if(exit == "네") {
//			
//		}
		
		while(true) {
			num = (int)(Math.random()*10)+1;
			System.out.println("홀입니까 짝입니까?");
			input = scan.nextInt();
			
			if(input %2 != num % 2){
				System.out.println("틀렸습니다 다시 값을 입력해주세요");
	
			}else if(input % 2 == num % 2) {
				if(input % 2 == 0) {
					answer = "짝수";
					System.out.println(answer + " 정답입니다.");
				}else {
					answer = "홀수";
					System.out.println(answer + " 정답입니다.");
				}
				break;
			}
		}
	}
}
