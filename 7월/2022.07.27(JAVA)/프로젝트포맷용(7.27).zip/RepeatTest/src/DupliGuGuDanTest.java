
public class DupliGuGuDanTest {

	public static void main(String[] args) {

		// i,j i = line = row()행 ---> 행 옆으로 ------------>
		// j = column()열 ---> 열 아래로 ↓
		String sum = "";

		for (int i = 2; i <= 9; i++) {
			System.out.print("구구단 " + i + "단" + ": ");
			for (int j = 1; j <= 9; j++) {
				sum = i + " * " + j + " = " + i * j + "\t"; // \t = tab
				System.out.print(sum);
			}
			System.out.println();
		}

		System.out.println("\n");
		System.out.println("\n");

		for (int i = 2; i <= 9; i++) {
			System.out.print("구구단 " + (i) + "단" + "        ");
		}

		for (int i = 0; i <= 9; i++) {
			for (int j = 2; j <= 9; j++) {
				sum = j + " * " + i + " = " + (j * i) + "\t";
				System.out.print(sum);
			}
			System.out.println();
		}

	}
}
