
public class DupliTriangleTest {
	public static void main(String[] args) {
		
//		직각삼각형
		for(int i=0; i<3; i++) {
			for(int j=1; j<3-i; j++) {
				System.out.print(" ");
			}for(int j=0; j<i+1; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
//		피라미드 정방향
		for (int i=0; i<5; i++) {
			for (int j=1; j<5-i; j++) {
				System.out.print(" ");
			}
			for (int j=0; j<i*2+1; j++) {
				System.out.print("$");
			}
			System.out.println();
		}
//		피라미드 역방향
		for (int i=5; i>0; i--) {
			for (int j=5-i; j > 0; j--) {
				System.out.print(" ");
			}
			for (int j=i*2-1; j > 0; j--) {
				System.out.print("$");
			}
			System.out.println();
		}		
//		피라미드 역방향 -1층(야매)
		for (int i=5; i>0; i--) {
			for (int j=5-i; j >= 0; j--) {
				System.out.print(" ");
			}
			for (int j=i*2-3; j > 0; j--) {
				System.out.print("$");
			}
			System.out.println();
		}
		
//		피라미드 정방향$
		for (int i = 0; i<5; i++) {
			for(int j = 1; j<5-i; j++) {
				System.out.print(" ");
			}
			for(int j = 0; j<i*2+1; j++) {
				System.out.print("$");
			}
			System.out.println();
		}
		
//		
		for (int i = 0; i < 5; i++) {
			for (int j = 1; j < 5 - i; j++) {
				System.out.print("☆");
			}
			for (int j = 0; j < i * 2 + 1; j++) {
				System.out.print("★");
			}
			for (int j = 1; j < 5 - i; j++) {
				System.out.print("☆");
			}
			System.out.println();
		}

		for (int i = 5; i > 0; i--) {
			for (int j = 5 - i; j > 0; j--) {
				System.out.print("☆");
			}
			for (int j = i * 2 - 1; j > 0; j--) {
				System.out.print("★");
			}
			for (int j = 5 - i; j > 0; j--) {
				System.out.print("☆");
			}
			System.out.println();
		}

		//
		for (int i = 5; i > 0; i--) {
			for (int j = 5 - i; j > 0; j--) {
				System.out.print("☆");
			}
			for (int j = i * 2 - 1; j > 0; j--) {
				System.out.print("★");
			}
			for (int j = 5 - i; j > 0; j--) {
				System.out.print("☆");
			}
			System.out.println();
		}

		//
//		for (int i = 0; i < 5; i++) {
//			for (int j = 1; j < 5 - i; j++) {
//				System.out.print("☆");
//			}		
		
		for (int i=0; i<5; i++) {
			for (int j=1; j<5-i; j++) {
				System.out.print(" ");
			}
			for (int j=0; j<i*2+1; j++) {
				System.out.print("$");
			}
			System.out.println();
		}
		
		for (int i=5; i<0; i--) {
			for (int j=5-i; j<=0; j--) {
				System.out.print(" ");
			}
			for (int j=i*2-3; j<0; j--) {
				System.out.print("$");
			}
			System.out.println();
		}
//		
////		
//		
//		for (int i=5; i>0; i--) {
//		    for (int j=5-i; j>0; j--) {
//		    	System.out.print(" ");
//		    }
//		    for (int j=i*2-1; j>0; j--) {
//		    	System.out.print("$");
//		    }
//		    System.out.println();
//		}		


		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		for (int i = 0; i < 5; i++) {
			for(int j = 1; j < 5 - i; j ++) {
				System.out.print(" ");
			}
			for(int j = 0; j < i*2+1; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		for (int i = 5; i > 0; i--) {
			for(int j = 5-i; j > 0; j--) {
				System.out.print(" ");
			}
			for(int j = i*2-1; j > 0; j--) {
				System.out.print("*");
			}
			System.out.println();
		}
//	
		
	}
}
