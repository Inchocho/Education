
public class RepeatTest1 {

	public static void main(String[] args) {

//		1부터 10까지의 정수를 줄바꿈해서 출력		
		for (int i = 1; i <= 10; i++) {
			System.out.println(i);
		}

		int sum = 0;
		int i = 0;

//		1부터 10까지의 정수를 모두 더한 값을 구하는 프로그램
		for (i = 1; i <= 10; i++) {
			sum = sum + i;
		}

		System.out.println("1~10까지의 합: " + sum);
		System.out.println("1~" + (i-1) + "까지의 합: "+sum);
		
//		1부터 9까지 구구단 프로그램		
		String multi = "";
		for(int i2 = 1; i2 < 10; i2++) {
			for(int j = 1; j<10; j++) {
				multi = i2 +"*" + j + "=" + i2*j;
				System.out.println(multi);
			}
			System.out.println();
		}
	}
}
