
public class WhileTest2 {
	public static void main(String[] args) {

		int cNum = 0;
		int sum = 0;
		
		while (true) {
			cNum++;
			System.out.print(cNum + " ");
			if (cNum % 5 == 0) {
				System.out.println();
			}
			sum = sum + cNum;
			if (cNum == 50) {
				System.out.println("합계: " + sum);
				break;
			}
		}
		System.out.println("프로그램 종료");
	}
}
