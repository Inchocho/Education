
public class VarMateInfo {		
	public static void main(String[] args) {
		
		//이름, 나이
		String name = "이영빈";
		String name2 = "유지효";				
		
		int age = 30;
		int age2 = 33;		
						
		System.out.println(name+"님의 나이는 "+age+"살 입니다.");
		System.out.println(name2+"님의 나이는 "+age2+"살 입니다.");		
		
		String changename = "김똘똘";
		int changeage = 25;
		
		System.out.println(changename+"님의 나이는 "+changeage+"살 입니다");
		
		changename = "박똘똘";
		changeage = 15;		
		
		System.out.println(changename+"님의 나이는 "+changeage+"살 입니다");
		
		changename = "최똘똘";
		changeage = 5;				
		
		System.out.println(changename+"님의 나이는 "+changeage+"살 입니다");		
						
	}

}
