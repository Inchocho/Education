public class VarTypeConcatTest {
	public static void main(String[] args) {
		String name;
		String str;
		int num = 0;
		
		name = "이젠";
		str = "학원";
		
		name = str + num;
		
		System.out.println(name);
		
		str = "아카데미";
		
		name = name + str + num + 5;
		System.out.println("정답은?: " + name);
		
		System.out.println(""+7+7);
		System.out.println(7+7+"");
	}
	
}