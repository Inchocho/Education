//for문 for(i = 1;(초기화) i < 10;(조건식) i++(증감식))
public class Condition_for_1 {
	static int MAX = 100;

	public static void main(String[] args) {
//		tNum 카운트까지
		int tNum = 0;
		int cntNum = 0;
		
		for(cntNum=0; cntNum<5; cntNum++) {
			tNum += cntNum;			
		}
		
		System.out.println("1 ~ " + (cntNum-1) + "합 : " + tNum);
		
//		for문 연습
		int sum = 0;
		for (int i = 0; i < 5; i++) {
			sum = sum + i;
			System.out.println(sum);
		}
		System.out.println(sum);
		sum = 0;

		for (int num = 0; num < 10; num++) {
			sum = sum - num;
			if (sum < -30) {
				sum = sum * MAX;
				sum = sum / num;
			}
		}
		System.out.println(sum);
		sum = 0;

		for (int serialNum = 0; serialNum <= 10; serialNum++) {
			System.out.print(serialNum + " ");
		}
		System.out.print("\n");

		for (int num = 0; num < 10; num += 2) {
			if (num > 0) {
				System.out.println(num);
			}
		}

//		 이중for문
		int i = 0;
		for (i = 1; i < 5; i++) {
			System.out.print("☆");
			for (int j = 1; j < 5 - i; j++) {
				System.out.print("★" + "\n");
			}
		}

		System.out.println();

//		 for문 변수 2개이상 포함
		int summ = 0;
		for (int ii = 0, jj = 100; ii < jj && jj > 50; ii += 5, jj -= 2) {
			if (jj > 60 && jj < 80) {
				System.out.print(jj + " ");
			}
			summ = ii + jj;
		}
		System.out.println();
		System.out.println(summ);

//		로또번호 6개뽑기		
		int lottoNum = 0;

		for (int cnt = 0; cnt < 6; cnt++) {
			lottoNum = (int) (Math.random() * 45) + 1;
			System.out.print(lottoNum + " ");
		}
		System.out.println(lottoNum);

//		방문횟수 for문
		int visitCnt = 0;

		for (visitCnt = 1;; visitCnt++) {
			System.out.println(visitCnt + "번 방문하셨습니다.");
			if (visitCnt == 1) {
				System.out.println("처음 오셨습니다.");
			}
			if (visitCnt > 19) {
				System.out.println("영업종료");
				return;
			}
		}

	}

}
