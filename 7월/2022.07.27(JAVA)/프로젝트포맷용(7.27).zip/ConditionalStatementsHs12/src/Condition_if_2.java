//if문 if(조건1){조건1의 결과가 true면 여기 실행}else{조건 1의 결과가 false면 여기 실행};

public class Condition_if_2 {
	public static void main(String[] args) {

		int score = 90;

		if (score < 50) {
			System.out.println("F");
		} else if (score > 60 && score < 70) {
			System.out.println("D");
		} else if (score > 70 && score < 80) {
			System.out.println("C");
		} else if (score > 80 && score < 90) {
			System.out.println("B");
		} else {
			System.out.println("A");
		}

		int ranNum = (int) (Math.random() * 100);
		System.out.println(ranNum);
		
//		Scanner scan = new Scanner(System.in);
//		System.out.println("점수를 입력하세요.");
//		int math = scan.nextInt();
//		String grade = "";
//		if (math >= 90) {
//			grade = "A";
//			if (math > 100) {
//				System.out.println("입력값을 확인하세요.");
//				return;
//			} else if (math >= 95) {
//				grade = grade + "+";
//			} else if (math <= 93) {
//				grade = grade + "-";
//			}
//		} else if (math >= 80) {
//			grade = "B";
//			if (math >= 85) {
//				grade = grade + "+";
//			} else if (math <= 83) {
//				grade = grade + "-";
//			}
//		} else {
//			grade = "F";
//		}
//
//		System.out.println(math + "점, 등급은 " + grade + " 입니다.");
//		
		
//		if문 실행방식
//		if(조건식1) {
//			조건식1이 true면 여기가 실행
//		}else if(조건식2) {
//			조건식2가 true면 여기가 실행
//		}
		
//		중첩if문을 사용하지 않고 학점 +,0,- 처리
//		높은순서대로 작성하는게 제일 중요함 이경우
		
		int score2 = 95;
		
		String grade2 = "";
		if(score2 >= 95) {
			grade2 = "A+";
		}else if(score2 >= 93) {
			grade2 = "A";
		}else if(score2 >= 90) {
			grade2 = "A-";
		}else if(score2 >= 85) {
			grade2 = "B+";
		}else if(score2 >= 83) {
			grade2 = "B";
		}else if(score2 >= 80) {
			grade2 = "B-";
		}		
		System.out.println(score2 + "<- 점수 등급 ->" + grade2);

	}
}
