//switch switch(변수){ case 값1:(변수값 1일경우 여기실행) case 값2:(변수값 1일경우 여기실행) 
//break(만나면 종료) default: 변수값이 1,2 모두 아닐 경우
public class Condition_switch_3 {
	public static void main(String[] args) {
		int diceNum = (int) (Math.random() * 6) + 1;

		switch (diceNum) {
			case 1:
				System.out.println("주사위 눈 1");
				break;
			case 2:
				System.out.println("주사위 눈 2");
				break;
			case 3:
				System.out.println("주사위 눈 3");
				break;
			case 4:
				System.out.println("주사위 눈 4");
				break;
			case 5:
				System.out.println("주사위 눈 5");
				break;
			default:
				System.out.println("주사위 눈 6");
				break;
		}

//switch break없으면 변수에 만족한 case문 이하 전체를 실행함 
// ex 주사위눈이 1이나올경우 case1부터 default까지 전부실행
//		switch (diceNum) {
//			case 1:
//				System.out.println("주사위 눈 1");
//			case 2:
//				System.out.println("주사위 눈 2");
//			case 3:
//				System.out.println("주사위 눈 3");
//			case 4:
//				System.out.println("주사위 눈 4");
//			case 5:
//				System.out.println("주사위 눈 5");
//			default:
//				System.out.println("주사위 눈 6");
//		}

//		문자타입 switch( A -> a 순서대로 실행되므로 우수회원 실행되고 break)		
		char grade = 'A';

		switch (grade) {
			case 'A':
			case 'a':
				System.out.println("우수 회원");
				break;
			case 'B':
			case 'b':
				System.out.println("일반 회원");
				break;
			default:
				System.out.println("손님");
		}

//		문자열타입 switch( A -> a 순서대로 실행되므로 우수회원 실행되고 break)
		String position = "과장";

		switch (position) {
			case "사장":
				System.out.println("500만원");
				break;
			case "과장":
				System.out.println("400만원");
				break;
			default:
				System.out.println("300만원");
			}
	}
}
