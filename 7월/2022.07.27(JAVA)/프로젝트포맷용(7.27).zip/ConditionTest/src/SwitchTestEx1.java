
public class SwitchTestEx1 {
	public static void main(String[] args) {

//		500번의 상품 컴퓨터 추가
//		100번이든 꽝이든 자신의 번호를 출력
//		꽝인 경우에는 당신의 번호는 ??입니다. 꽝 다음기회에
//		임의의 숫자를 받아서 사용 Math.random();

//		(int)(Math.random()*n) --> n은 난수범위를 몇까지 정할지 0~n-1까지를 나타냄 (총 n가지)
//		1부터 생성하려면 마지막에 (Math.random()*n)+1 -> 1~n까지
//		choiceNum = choiceNum * 100;		

		int choiceNum = 0;
		choiceNum = (int) (Math.random() * 10);
		choiceNum = choiceNum * 100;
		
		System.out.print("당신의 번호는 " + choiceNum + "번 입니다. ");

		switch (choiceNum) {
		case 100:
			System.out.println("당첨: 자전거");
			break;
		case 200:
			System.out.println("당첨: TV");
			break;
		case 300:
			System.out.println("당첨: 노트북");
			break;
		case 400:
			System.out.println("당첨: 자동차");
			break;
		case 500:
			System.out.println("당첨: 컴퓨터");
			break;
		default:
			System.out.println(" 꽝 다음 기회를 기대해주세요");
			break;
		}

	}
}
