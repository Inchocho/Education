import java.util.*;

public class FlowTestEx1 {
	public static void main(String[] args) {

//		재방문 출력 프로그램
//		다시 방문 해주셔서 감사합니다

//		항상출력
//		방문 횟수는 n번입니다. 라고 출력

		int visitCnt = 0;

		visitCnt = 0;

		if (visitCnt == 0) {
			System.out.println("처음 오셨군요.");
			System.out.println("방문해 주셔서 감사합니다.");
		} else {
			System.out.println("다시 방문해주셔서 감사합니다.");
		}

		visitCnt++;
		System.out.println(visitCnt + "번 방문하셨습니다.");
		
//		학점을 등급으로 표현하는 프로그램
//		90점이상~ A
//		90점미만~80점이상 B
//		80점미만~70점이상 C 
//		70점미만~60점이상 D
//		나머지 F 로 출력
		
//		점수는 사용자 키보드 입력을 받는다.
		
				
	}
}
