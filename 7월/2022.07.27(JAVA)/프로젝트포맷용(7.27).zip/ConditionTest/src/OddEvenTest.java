import java.util.*;

public class OddEvenTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan = new Scanner(System.in);
		System.out.println("숫자를 입력하세요.");
		int chkNum = scan.nextInt();
		
		if(chkNum > 0) {
			System.out.println(chkNum+" = 양수");
		}
		if(chkNum < 0) {
			System.out.println(chkNum+" = 음수");
		}
		if(chkNum == 0) {
			System.out.println(chkNum+" = 0");
		}
		
		scan.close();		
	}

}
