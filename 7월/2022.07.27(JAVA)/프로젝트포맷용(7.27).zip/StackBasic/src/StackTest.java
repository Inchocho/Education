//	-JVM 흐름을 알기위한 예시	
//	-메서드가 호출되면 수행에 필요한 만큼의 메모리를 스택에 할당받는다
//	-메서드가 반드시 종료된 후 다음 메서드가 실행된다.
//	-메서드가 수행을 마치고나면 사용했던 메모리를 반환하고 스택에서 제거된다
//	-호출스택의 제일 위에 있는 메서드가 현재 실행 중인 메서드이다
//	-아래에 있는 메서드가 바로 위의 메서드를 호출한 메서드이다

//(1) 먼저 main메서드가 스택에 쌓인다(FILO) FirstInLastOut 스택
//(2) firstClass.firstMethod() 메서드를 호출한다
//(3) firstMethod()에서 secondMethod()를 호출한다
//(4) System.out.println()를 호출한다(출력메서드)
//(5) sysout 출력메소드 종료  메모리반환 후 스택에서 제거
//(6) secondMethod() 종료  메모리반환 후 스택에서 제거
//(7) firstMethod()  종료  메모리반환 후 스택에서 제거
//(8) main() 종료 메모리 반환 후 스택에서 제거, 프로그램 종료

public class StackTest {

	public static void main(String[] args) {
		
		FirstClass firstClass = new FirstClass();
		
		firstClass.firstMethod();
		
	}
}
