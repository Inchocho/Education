
public class InstanceBasic2 {

	int iv;
	static int cv;

	void instanceMethod2() { //인스턴스메소드
		System.out.println(iv);
		System.out.println(cv);
	}

	static void staticMethod2() { //스태틱메소드
//		System.out.println(iv); -- 에러나는 이유 인스턴스변수는 인스턴스 생성시 생성되므로 static메소드 시점에서는 아직 존재하지 않는다. 
		System.out.println(cv);
	}
}
