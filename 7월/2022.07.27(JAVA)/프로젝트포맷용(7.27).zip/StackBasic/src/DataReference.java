
public class DataReference {

	int num = 0;
	
	void change(DataReference dataReference) {

		num = 1000;

		System.out.println("change()에서의 num: " + num);
	}
}
