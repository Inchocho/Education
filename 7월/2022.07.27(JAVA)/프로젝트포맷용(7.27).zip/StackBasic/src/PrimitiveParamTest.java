//기본형 매개변수와 참조형 매개변수

//기본형 매개변수
//변수의 값을 읽기만 할 수 있다 (read only)
//
//참조형 매개변수
//변수의 값을 읽고 변경할 수 있다 (read & write)


public class PrimitiveParamTest {

	public static void main(String[] args) {
		
		Data data = new Data();
		int num = 10;
		
		System.out.println("main에서 num: " + num);
		
		data.change(num);
		
		System.out.println("change 메서드 수행 후 num: " + num);
	}
}
