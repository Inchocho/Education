
public class ReferenceParamTest {

	public static void main(String[] args) {
		
		DataReference dataReference = new DataReference();
		int num = 10;
		
		dataReference.num = num;
		
		System.out.println("main에서 num: " + num);
		System.out.println("main에서 dataReference.num: " 
				+ dataReference.num);
		
		dataReference.change(dataReference);
		
		System.out.println("main에서 num: " + num);
		System.out.println("change 메서드 수행 후 dataReference.num: " 
				+ dataReference.num);
	}
}
