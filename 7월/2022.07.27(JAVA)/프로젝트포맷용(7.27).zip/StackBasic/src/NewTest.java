
public class NewTest {

	public static void main(String[] args) {

		Tv tv = new Tv();

		tv.power = true;

		new Tv().power = true;
		
		System.out.println(tv.power);
		System.out.println(new Tv().power);
	}
}
