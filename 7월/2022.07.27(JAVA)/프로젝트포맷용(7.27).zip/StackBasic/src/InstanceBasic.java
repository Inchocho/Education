
public class InstanceBasic {	
		
//		스태틱 메서드와 인스턴스 메서드
//		
//		1.클래스를 설계할 때, 멤버변수 중 모든 인스턴스에 공통적으로
//		사용해야하는 것에 static을 붙인다
//		-생성된 각 인스턴스는 서로 독립적이기 때문에 각 인스턴스의 변수(iv)는
//		서로 다른 값을 유지한다 그러나 모든 인스턴스에서 같은 값이 유지되어야
//		하는 변수는 static을 붙여서 스태틱 변수로 정의한다
//		
//		2.스태틱 변수는 인스턴스를 생성하지 않아도 사용할 수 있다
//		-static이 붙은 변수는 클래스가 메모리에 올라갈 때 이미
//		자동적으로 생성되기 때문이다
//		
//		
//		3.스태틱 변수(스태틱 메서드)는 인스턴스 변수를 사용 할 수 없다		
//		-인스턴스변수는 인스턴스가 반드시 존재해야만 사용할 수 있는데
//		스태틱 메서드는 인스턴스 생성 없이 호출가능하므로 스태틱 메서드가 
//		호출되었을 때 인스턴스가 존재하지 않을 수도 있다
//		그래서 클래스 메서드에서 인스턴스변수의 사용을 금지한다
//		반면에 인스턴스변수나 인스턴스메서드에서는 static이 붙은 멤버들을
//		사용하는 것이 언제나 가능하다
//		인스턴스 변수가 존재한다는 것은 static 변수가 이미 메모리에 존재한다는
//		것을 의미하기 때문이다
//		
//		참고: static을 붙여야 할때?
//		절대적인 느낌의 것들
	
	void instanceMethod() {	//인스턴스 메소드
		System.out.println("인스턴스메소드 현재 a값: " + a);
		staticMethod();
		System.out.println("staticMethod 호출 후 a값: " + a);
	}
	
	void instanceMethod2() { //인스턴스 메소드
		System.out.println(a);
		instanceMethod();
		System.out.println(a);
		staticMethod();
		System.out.println(a);
	}
	
	static int a = 10;
	
	static void staticMethod() { //스태틱 메소드
		a++;
	}
	
	static void staticMethod2() { //스태틱 메소드
//		Cannot make a static reference to the non-static method instanceMethod() from the type InstanceBasic
//		스태틱메소드가 생성된 시점에서 스태틱메소드가 아닌 인스턴스메소드인 instance메소드는 아직 생성되지 않았기때문에 사용불가하다.		
//		instanceMethod();	//에러나는 이유 => 스태틱메소드에서 인스턴스 메소드를 사용했기 때문이다.
		staticMethod();
	}
	
	public static void main(String[] args) {
		InstanceBasic ins = new InstanceBasic();
		ins.instanceMethod();
		ins.instanceMethod2();
		ins.staticMethod2();
	}
	
}
