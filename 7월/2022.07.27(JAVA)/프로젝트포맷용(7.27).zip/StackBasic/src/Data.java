
public class Data {
	
	int num = 0;

	void change(int num) {

		num = 1000;

		System.out.println("change()에서의 num: " + num);
	}
}
