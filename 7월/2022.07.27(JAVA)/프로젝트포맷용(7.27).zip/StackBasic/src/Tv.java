
public class Tv {

	String color = "";
	boolean power = false;
	int channel = 0;

	void power() { // TV를 키거나 끄는 기능
		power = !power;
	}

	void channelUp() { // 채널을 올리는 기능
		channel = channel + 1;
	}

	void channelDown() { // 채널을 낮추는 기능 메소드
		channel = channel + -1;
	}

	void changeChannel(int a) {
		channel = a;
	}

	public static void main(String[] args) {
//		new 연산자를 통해 Tv라는 클래스타입인 
//		color,power,channel의 객체변수와
//		channelUp,Down,changeChannel() 메소드를 가진 객체(인스턴스)가 생성된다.
		Tv tv = new Tv();
		tv.power();
		tv.channel = 25;
		tv.channelUp();
	}

}
