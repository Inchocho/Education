
public class DuplicateForEx1 {
	
	public static void main(String[] args) {
		
//		중첩 반복문
//		중첩 for문
//		
//		for(초기화,조건식1,증감식) {
//			for(초기화,조건식2,증감식) {
//				내부for문 수행(외부 for문이 true인상태) + (내부 for문이 조건이 만족할때까지 반복)				
//			}
//			(내부 for문이 조건이 불만족) -> 외부 for문 수행 -> 외부 for문 증감식 적용
//		}

//		첫번째 for문 조건식1 만족시 for문 블럭의 내용 수행
//		for블럭내부에 for문이 수행되서 내부for문의 조건식2도 만족시 내부for문 블럭내부의 내용이 수행
//		즉 내부for문의 내부내용은 for문의 조건식1이 true이고 내부for문 조건식2가 true이면 수행되고 
//		for문의 조건식1이 true면서 내부for문의 조건식2가 false면
//		내부for문 블럭 외부의 내용이 수행된다		

//		이중for문을 통한 구구단 예시		
		
		for(int i = 2; i <= 9; i++) {
			for(int n = 1; n <= 9; n++) {
				System.out.println(i + "*" + n 
						+ " = " + (i * n));
			}
			System.out.println();
		}
		
	}
}
