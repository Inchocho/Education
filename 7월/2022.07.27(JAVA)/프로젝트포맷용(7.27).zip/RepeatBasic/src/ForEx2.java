
public class ForEx2 {

	public static void main(String[] args) {
//		누적?
	
		int sum = 0;		
		int firstNum = 0;
		int secondNum = 0;
		
		firstNum = 10;
		secondNum = 2;
		
		sum = firstNum + secondNum;
		
		System.out.println(sum);
		
		sum = sum + 1;	// sum += 1;
		
		System.out.println(sum);
		
//		1~10 까지의 정수를 모두 더한 값을 구하는 프로그램 (예시)
		
		int sum2 = 0;
		
		for(int i=1; i<=10; i++) {
			sum2 = sum2+i;
//			검증(for문이 어떻게 실행되는지 출력한것)
			System.out.println(i + "번 반복까지의 합: " + sum2);
		}
		
		System.out.println(sum2);
		
	}
}
