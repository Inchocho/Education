
public class WhileEx1 {

	public static void main(String[] args) {
		
//		while문
//		
//		표현식
//		
//		while(조건식) {
//			조건식의 연산결과가 true일 때 수행될 문장들을 적는다
//		}
		
		int num = 3;
		
		while(num >= 0) {
			System.out.println(num);
			num--;
		}
		
		System.out.println("프로그램 종료" + "\n");
		
		int num2 = 5;
		String cando = "I Can Do It";
		
		while(num2 >= 1) {
			System.out.println(num2 + " - " + cando);
			num2--;
		}
		
		
	}
}
