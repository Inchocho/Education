import java.util.Scanner;

public class UpAndDown {

	public static void main(String[] args) {

		int input = 0;
		int answer = 0;

		answer = (int)(Math.random()*10)+1;
		Scanner scan = new Scanner(System.in);

		while (true) {
			System.out.println("1과 10 사이의 정수를 입력하세요.");
			input = scan.nextInt();

			if (input > answer) {
				System.out.println("더 작은 수로 다시 시도해주세요.");
			} else if (input < answer) {
				System.out.println("더 큰 수로 다시 시도해주세요.");
			}

			if (input == answer) {
				System.out.println("정답입니다.");
				break;	//break -> 반복문을 벗어나는데 사용된다. 종료시킴
			}
		}
		
		System.out.println("프로그램을 종료합니다");

	}
}
