
public class ForEx1 {

	public static void main(String[] args) {
		
//		반복문
//		
//		반복문은 어떤 작업이 반복적으로 수행되도록 할 때
//		사용된다
//		
//		표현식
//		for(초기화; 조건식; 증감식) {
//			조건식이 true일 때 수행될 문장들을 적는다
//		}
		
//		초기화한 값을 조건식을 연산해서 true가 나오면 for문 안의 문장을 수행한뒤 증감식에 따른 처리를함
//		(1) i = 1; 1<=5; true -> System.out.println(i); 1출력 실행됨 -> i++ 증감식
//		(2) i = 2; 2<=5; true -> System.out.println(i); 2출력 실행됨 -> i++ 증감식 ...
//		(6) i = 6; 6<=5; false -> for(){}문 종료 -> int i(지역변수) 소멸

		
		for(int i=1; i<=5; i++) {
			System.out.println(i);
		}
		
		for(int i=1; i<=5; i++) {
			System.out.print(i);
		}		
	}
}
