
public class ForEx3 {

	public static void main(String[] args) {

//		형상관리
//		git
//		에스테리크(*)
//		*
//		**
//		***

		System.out.println("===========직각삼각형=========");

		String star = "";

		for (int i = 1; i <= 3; i++) {
			star = star + "*";
			System.out.println(star);
		}

		System.out.println("===========직각삼각형1-1=========");
//		꽝임(출력은 되는데 코드가 구림)
		for (int i = 1; i <= 3; i++) {
			if (i == 1) {
				System.out.println("*");
			} else if (i == 2) {
				System.out.println("**");
			} else if (i == 3) {
				System.out.println("***");
			}
		}

		System.out.println("===========직각삼각형2 정방향=========");

		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= i - 1; j++) {
				System.out.print("*");
			}
			System.out.println("*");
		}

		System.out.println("========직각삼각형2 역순==========");

		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= 4 - i; j++) {
				System.out.print("*");
			}
			System.out.println("*");
		}

		System.out.println("========삼각형==========");

		for (int i=0; i<5; i++) {
		    for (int j=1; j<5-i; j++) {
		    	System.out.print("○");
		    }
		    for (int j=0; j<i*2+1; j++) {
		    	System.out.print("●");
		    }
		    for (int j=1; j<5-i; j++) {
		    	System.out.print("○");
		    }		    
		    System.out.println();
		}
		
		System.out.println("========역삼각형==========");
		
		for (int i=5; i>0; i--) {
		    for (int j=5-i; j>0; j--) {
		    	System.out.print("ㅁ");
		    }
		    for (int j=i*2-1; j>0; j--) {
		    	System.out.print("ㅅ");
		    }
		    for (int j=5-i; j>0; j--) {
		    	System.out.print("ㅁ");
		    }		    
		    System.out.println();
		}
		
		System.out.println("========피라미드형==========");
		
		//상단-중간
		for (int i=0; i<5; i++) {
		    for (int j=1; j<5-i; j++) {
		        System.out.print("#");
		    }
		    for (int j=0; j<i*2+1; j++) {
		        System.out.print("*");
		    }
		    for (int j=1; j<5-i; j++) {
		        System.out.print("#");
		    }		    
		    System.out.println();
		}
				
		//하단(상단 뒤집기)
		for (int i=5-1; i>0; i--) {
		    for (int j=5-i; j>0; j--) {
		        System.out.print("○");
		    }
		    for (int j=i*2-1; j>0; j--) {
		        System.out.print("●");
		    }
		    for (int j=5-i; j>0; j--) {
		        System.out.print("○");
		    }
		    System.out.println();
		}		

	}

}
