/*
 * 이 클래스에 자신의 이름과 대학교명을 출력하시오
 */
public class SampleProject_KSJ {

	public static void main(String[] args) {
		
		String name = "김소진";
		String sch = "인천미래생활고";
		
		System.out.println(name);
		System.out.println(sch);
	}

}

