package str.answer;

public class StringEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 절대 원본 데이터를 변경하지 않는다
		String originStr = "문자열 메서드를 활용haja하자"; // 기준
		int strIndex = 0; // 결과

		strIndex = originStr.indexOf("h");
//		h의 위치를 출력하시오 

		System.out.println(originStr);
		System.out.println(strIndex);

	}

}
