package the.good.test;

import the.good.gugudan.Gugudan;

public class EducationMathTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Gugudan gugudan = new Gugudan();
		
		String resultStr = "";
		
		gugudan.setGugudan(5);
		
		resultStr = gugudan.getGugudan();
		
		System.out.print(resultStr);
		
	}

}
