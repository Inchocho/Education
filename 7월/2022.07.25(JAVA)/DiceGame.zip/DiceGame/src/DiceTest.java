
public class DiceTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Dice dice = new Dice();
		
		dice.diceRoll();
		
		dice.viewDiceNum();
		
		
		
	}

}
