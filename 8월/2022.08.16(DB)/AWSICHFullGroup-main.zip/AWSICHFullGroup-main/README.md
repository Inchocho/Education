# AWSICHFullGroup
AWS과정 수업 테스트
