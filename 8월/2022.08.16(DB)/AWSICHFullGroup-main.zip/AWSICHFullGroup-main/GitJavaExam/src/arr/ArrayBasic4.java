package arr;
public class ArrayBasic4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] numberArr = new int[4];

		numberArr[4] = 2;

		
		for (int i = 0; i < numberArr.length; i++) {
			System.out.println(numberArr[i]);
		}
		
		

	}

}
