package arr;

public class ArrayBasic2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] numberArr = new int[4];
		
		numberArr[1] = 2;
		
		
		System.out.println(numberArr[1]);
		
	}

}
