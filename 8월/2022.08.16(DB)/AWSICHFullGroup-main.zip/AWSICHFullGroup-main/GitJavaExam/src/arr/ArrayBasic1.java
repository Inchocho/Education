package arr;


public class ArrayBasic1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] numberArr = new int[4];
		
		numberArr[0] = 1;
		numberArr[1] = 2;
		numberArr[2] = 3;
		numberArr[3] = 4;
		
				
		System.out.println(numberArr[1]);
		System.out.println(numberArr[2]);
		System.out.println(numberArr[3]);
		System.out.println(numberArr[4]);
		
		
		
		
	}

}
