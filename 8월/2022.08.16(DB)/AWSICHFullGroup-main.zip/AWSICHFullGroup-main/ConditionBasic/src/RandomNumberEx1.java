
public class RandomNumberEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		랜덤한 숫자
//		임의의 숫자를 구하는 방법
		
		int rndNum = 0;
		
		rndNum = (int)(Math.random() * 10);
		
		System.out.println(rndNum);
	}

}
