
public class FlowEx2 {

	public static void main(String[] args) {

//		if-else문
//		
//		if(조건식) {
//			조건식이 참 일때 수행될 문장을 적는다
//		}else {
//			조건식이 거짓일 때 수행될 문장을 적는다
//		}
		
		int num = 0;
		
		if(num == 0) {
			System.out.println("입력하신 숫자는 0입니다.");
		}else {
			System.out.println("입력하신 숫자는 0이 아닙니다.");
		}
		
	}

}
