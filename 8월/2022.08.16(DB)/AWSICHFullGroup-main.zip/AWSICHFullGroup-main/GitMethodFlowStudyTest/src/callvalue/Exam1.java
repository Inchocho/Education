package callvalue;

public class Exam1 {
	
	int add(int x, int y){
		int result = 0;
		
		System.out.println(result);
		
		x++;
		y++;
		
		result = x + y;
		
		return result;
	}
	
}
