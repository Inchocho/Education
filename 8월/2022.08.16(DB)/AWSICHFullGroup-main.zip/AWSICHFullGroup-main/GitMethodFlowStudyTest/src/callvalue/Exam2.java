package callvalue;

public class Exam2 {
	
	int add(int[] x, int[] y){
		int result;
		
		x[0]++;
		y[0]++;
		
		result = x[0] + y[0];
		
		return result;
	}
	
}
