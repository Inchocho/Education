package methodflow;

public class MethodFlowTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		FirstClass2 cs2 = 
				new FirstClass2();
		
		cs2.firstMethod();
		
		
	}

}
