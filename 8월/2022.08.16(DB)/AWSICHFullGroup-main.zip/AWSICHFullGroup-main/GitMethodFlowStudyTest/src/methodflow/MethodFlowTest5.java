package methodflow;

public class MethodFlowTest5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		FirstClass5 cs = 
				new FirstClass5();
		
		FirstClass5 ccss = 
				new FirstClass5();
		
		cs.firstMethod();
		
		ccss.fourth();
		
	}

}
