package methodflow;

public class MethodFlowTest3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("main시작");
		FirstClass3 cs3 = 
				new FirstClass3();
		
		cs3.firstMethod();
		
	}

}
