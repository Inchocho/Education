package methodflow;

public class MethodFlowTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		FirstClass cs = 
				new FirstClass();
		
		System.out.println("main 메서드 시작");
		
		cs.firstMethod();
		
		System.out.println("main 메서드 끝");
		
	}

}
