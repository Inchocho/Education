package methodflow;

public class MethodFlowTest4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		FirstClass4 cs = 
				new FirstClass4();
		
		cs.firstMethod();
		
		cs.secondMethod();
		
	}

}
