package kr.co.ezen;

public class HelloDao {

	public int addTwoNumber(int a, int b) {
		
		return a + b;
	}
	
}
