package kr.co.ezen;

public class HelloMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HelloDao helloDao = new HelloDao();
		
		int reulst = helloDao.addTwoNumber(3, 5);
		
		System.out.println(reulst);
		
	}

}
