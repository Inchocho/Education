package com.edu.member.service;

import java.util.List;

import com.edu.member.model.MemberDto;

public interface MemberService {

	public List<MemberDto> memberSelectList();
	
}
