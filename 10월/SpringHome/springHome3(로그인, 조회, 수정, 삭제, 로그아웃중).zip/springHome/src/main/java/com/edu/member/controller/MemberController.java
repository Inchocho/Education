package com.edu.member.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.edu.member.model.MemberDto;
import com.edu.member.service.MemberService;

// 어노테이션 드리븐
@Controller
public class MemberController {

	private static final Logger logger 
		= LoggerFactory.getLogger(MemberController.class);
	
	@Autowired
	private MemberService memberService;
	
	@RequestMapping(value = "/login.do", method = RequestMethod.GET)
	public String login(HttpSession session, Model model) {
		logger.info("Welcome MemberController login! ");
		
		
		return "auth/LoginForm";
	}
	
	@RequestMapping(value = "/loginCtr.do", method = RequestMethod.POST)
	public String loginCtr(String email, String password
			, HttpSession session, Model model) {
		logger.info("Welcome MemberController loginCtr! " + email 
			+ ", " + password);
		
		MemberDto memberDto = memberService.memberExist(email, password);
		
		if(memberDto != null) {
			session.setAttribute("member", memberDto);
			
			return "redirect:/member/list.do";
		}
		
		return "/auth/LoginFail";
	}
	
	//로그아웃
	@RequestMapping(value = "/logout.do", method = RequestMethod.GET)
	public String logout(HttpSession session, Model model) {
		logger.info("Welcome MemberController logout! ");
		
		session.removeAttribute("member");
//		session.invalidate();
		
		return "redirect:/login.do";
	}
	
	@RequestMapping(value = "/member/list.do", method = RequestMethod.GET)
	public String memberList(Model model) {
		logger.info("Welcome MemberController memberList!");
		
		List<MemberDto> memberList = memberService.memberSelectList();
		
		model.addAttribute("memberList", memberList);
		
		return "member/MemberListView";
	}
	
	@RequestMapping(value = "/member/add.do", method = RequestMethod.GET)
	public String memberAdd(Model model) {
		logger.debug("Welcome MemberController memberAdd! ");
		
		
		return "member/MemberForm";
	}
	
	@RequestMapping(value = "/member/addCtr.do", method = RequestMethod.POST)
	public String memberAdd(MemberDto memberDto, Model model) {
		logger.info("Welcome MemberController memberAdd! " + memberDto);
		
		memberService.memberInsertOne(memberDto);
		
		
		return "redirect:/member/list.do";
	}
	
	// 회원수정 화면으로
	@RequestMapping(value = "/member/update.do", method = RequestMethod.GET)
	public String memberUpdate(int no, Model model) {
		logger.debug("Welcome MemberController memberUpdate! " + no);
		
		MemberDto memberDto = memberService.memberSelectOne(no);
		
		model.addAttribute("memberDto", memberDto);
		
		return "member/MemberUpdateForm";
	}

	// 회원수정
	@RequestMapping(value = "/member/updateCtr.do"
		, method = RequestMethod.POST)
	public String memberUpdateCtr(MemberDto memberDto, Model model) {
		logger.info("Welcome MemberController memberUpdateCtr! " 
			+ memberDto);
		
		memberService.memberUpdateOne(memberDto);
		
		return "redirect:/member/list.do";
	}
	
	// 회원탈퇴
	@RequestMapping(value = "/member/delete.do", method = RequestMethod.GET)
	public String memberDelete(int no, Model model) {
		logger.info("Welcome MemberController memberDelete! " + no);
		
		memberService.memberDeleteOne(no);
		
		return "redirect:/member/list.do";
	}
}
