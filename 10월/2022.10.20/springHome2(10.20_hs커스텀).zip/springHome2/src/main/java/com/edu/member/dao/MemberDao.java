package com.edu.member.dao;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.edu.member.model.MemberDto;

public interface MemberDao {

	public List<MemberDto> memberSelectList(int start, int end);
	public MemberDto memberExist(String email, String password);
	public int memberInsertOne(MemberDto memberDto, MultipartHttpServletRequest mulRequest);
	public MemberDto memberSelectOne(int no);
	public int memberUpdateOne(MemberDto memberDto);

	public void memberDeleteOne(int no);
	public int memberSelectTotalCount();
	public void insertFile(Map<String, Object> map);

	public List<Map<String,Object>> fileSelectList(int no);
	public Map<String, Object> fileSelectStoredFileName(int parentSeq);
	public int fileDelete(int parentSeq);
	
	//검색기능 추가한 조회 (10.20 4시)
	public List<MemberDto> memberSelectList2(int start, int end, String search);
	public int memberSelectSearchCount(String search);

}
