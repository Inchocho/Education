package com.edu.member.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.edu.member.model.MemberDto;

public interface MemberService {

	public List<MemberDto> memberSelectList(int start, int end);

	public MemberDto memberExist(String email, String password);
	
	public void memberInsertOne(MemberDto memberDto, MultipartHttpServletRequest mulRequest) throws Exception;

	public Map<String, Object> memberSelectOne(int no);

	public int memberUpdateOne(MemberDto memberDto
			, MultipartHttpServletRequest multipartHttpServletRequest
			, int fileIdx) throws Exception;

	public void memberDeleteOne(int no);

	public int memberSelectTotalCount();

	//검색기능 추가한 조회목록(10.20 4시)
	public List<MemberDto> memberSelectList2(int start, int end, String search);

	//검색기능 추가한 조회목록(10.20 4시)
	public int memberSelectSearchCount(String search);
	
}
